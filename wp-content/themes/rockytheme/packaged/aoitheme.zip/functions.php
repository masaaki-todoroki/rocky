<?php
require_once('lib/helpers.php');
require_once('lib/enqueue-assets.php');

function after_pagination()
{
  echo 'test';
}
add_action('aoitheme_after_pagination', 'after_pagination');
