<?php get_header(); ?>

<?php if (have_posts()) : ?>
    <?php while (have_posts()) : ?>
        <?php the_post(); ?>
        <h2>
            <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
                <?php the_title(); ?>
            </a>
        </h2>
        <div>
            <?php aoitheme_post_meta(); ?>
        </div>　
        <div>
            <?php the_excerpt(); ?>
        </div>
        <?php aoitheme_readmore_link(); ?>
    <?php endwhile; ?>
    <?php the_posts_pagination(); ?>
<?php else : ?>
    <p><?php esc_html_e('Sorry, no posts matched your criteria.', 'aoitheme'); ?></p>
<?php endif; ?>
<?php
$city = 'london';
echo esc_html__('Your city is ', 'aoitheme') . $city;
printf(esc_html__('Your city is %s', 'aoitheme'), $city)
?>
<?php get_footer(); ?>